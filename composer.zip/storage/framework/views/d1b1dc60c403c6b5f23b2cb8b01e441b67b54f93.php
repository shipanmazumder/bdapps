<footer class="footer text-right">
        <?php echo e(date("Y")); ?> © BDAPPS DAIRY.
    </footer>
<?php /**PATH G:\shipan\htdocs\bdapps\resources\views/layout/footer.blade.php ENDPATH**/ ?>