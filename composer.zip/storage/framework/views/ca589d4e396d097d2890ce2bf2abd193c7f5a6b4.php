<?php $__env->startSection('title_area'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_section'); ?>
    <div class="content">
     <?php if(Session::has('message')): ?>
        <div class="alert alert-<?php echo e(Session::get("class")); ?>"><?php echo e(Session::get("message")); ?></div>
     <?php endif; ?>
    <div class="container">
        <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <h4 class="pull-left page-title">Welcome To Dashboard !</h4>
                <ol class="breadcrumb pull-right">
                    <li><a href="#"><?php echo e(config('app.name')); ?></a></li>
                    <li class="active">Dashboard</li>
                </ol>
            </div>
        </div>

        <!-- Start Widget -->
            <div class="row">
                <div class="col-md-4 col-sm-6 col-lg-3">
                    <div class="mini-stat clearfix bx-shadow">
                        <span class="mini-stat-icon bg-info"><i class="md  md-shopping-basket"></i></span>
                        <div class="mini-stat-info text-right text-muted">
                            <span class=""><?php echo e($install_app); ?>/<?php echo e(config('app.total_install_limit')); ?></span>
                            Total Install
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-lg-3">
                    <div class="mini-stat clearfix bx-shadow">
                        <span class="mini-stat-icon bg-primary"><i class="md  md-wallet-giftcard"></i></span>
                        <div class="mini-stat-info text-right text-muted">
                            <span class="counter"><?php echo e($total_left); ?></span>
                            Total Left
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 col-lg-3">
                    <div class="mini-stat clearfix bx-shadow">
                        <span class="mini-stat-icon bg-info"><i class="fa fa-usd"></i></span>
                        <div class="mini-stat-info text-right text-muted">
                            <span class="counter">0.00</span>
                           Monthly Fee
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php if(isset($total_apps)): ?>
                    <?php $__currentLoopData = $total_apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url("user/app-content/".$value['id'])); ?>">
                            <div class="col-md-4 col-sm-6 col-lg-3">
                                <div class="mini-stat clearfix bx-shadow">
                                    <span class="mini-stat-icon bg-<?php echo e($value['class_name']); ?>"><i class="md  md-question-answer"></i></span>
                                    <div class="mini-stat-info text-right text-muted">
                                        <span class="counter"> <?php echo e($value['app_remain_sms']); ?></span>
                                        <?php echo e($value['app_name']); ?>

                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
        </div> <!-- container -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\shipan\htdocs\bdapps\resources\views/user/dashboard/dashboard.blade.php ENDPATH**/ ?>