<footer class="footer text-right">
        2018-{{date("Y")}} © Wan It Ltd.
    </footer>