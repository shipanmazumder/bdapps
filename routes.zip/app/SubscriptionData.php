<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubscriptionData extends Model
{
    //
}
