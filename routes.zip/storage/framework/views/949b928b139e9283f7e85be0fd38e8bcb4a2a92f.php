<footer class="footer text-right">
        <?php echo e(date("Y")); ?> © BDAPPS DAIRY.
    </footer>
<?php /**PATH D:\shipan7.2\htdocs\bdapps\resources\views/layout/footer.blade.php ENDPATH**/ ?>