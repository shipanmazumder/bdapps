<?php $__env->startSection("title_area"); ?>
    Profile Change
<?php $__env->stopSection(); ?>
<?php $__env->startSection("main_section"); ?>
     <div class="content">
        <?php if(Session::has('message')): ?>
            <div class="alert alert-<?php echo e(Session::get("class")); ?>"><?php echo e(Session::get("message")); ?></div>
        <?php endif; ?>
        <div class="container">
            <div class="row">
                    <?php echo Form::open(['url' => 'password-change',"method"=>"post"]); ?>

                    <div class="col-sm-12">
                        <div class="panel-group panel-group-joined" id="accordion-test">
                            <div class="panel panel-border panel-info">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <a data-toggle="collapse" data-parent="#accordion-test" href="#collapseOne" class="collapsed">
                                            Profile Change
                                        </a>
                                    </h3>
                                </div>
                                <div id="collapseOne" class="panel-collapse collapse in">
                                    <div class="panel-body">
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="email">Email</label><small class="req">*</small>
                                                <input <?php echo e(Auth::user()->role->id==2?"readonly":""); ?>  name="email" type="email" value="<?php echo e(Auth::user()->email); ?>" class="form-control" id="email">
                                                <input   name="id" type="hidden" value="<?php if(isset($single)): ?><?php echo e($single->id); ?> <?php endif; ?>">
                                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="oldPass">Old Password</label><small class="req">*</small>
                                                <input   name="oldPass" type="password"  class="form-control" id="oldPass">
                                                <?php $__errorArgs = ['oldPass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-3">
                                            <div class="form-group">
                                                <label for="password">New Password</label><small class="req">*</small>
                                                <input   name="password" type="password"  class="form-control" id="password">
                                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                        <div class="col-sm-3">
                                            <div class="form-group pull-left m-t-22">
                                                <input type="submit" class=" btn btn-primary pull-right" value="Change" name="submit" />
                                            </div>
                                        </div>
                                    </div> <!-- panel-body -->
                                </div>
                            </div> <!-- panel -->
                        </div>
                    </div> <!-- col -->
                    <?php echo Form::close(); ?>

            </div> <!-- End row -->
        </div> <!-- container -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\shipan7.2\htdocs\bdapps\resources\views/login/passwordChange.blade.php ENDPATH**/ ?>