<?php $__env->startSection('title_area'); ?>
Schedule SMS
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_section'); ?>
    <div class="content">
        <div class="container">
             <?php if(Session::has('message')): ?>
                <div class="alert alert-<?php echo e(Session::get("class")); ?>"><?php echo e(Session::get("message")); ?></div>
             <?php endif; ?>
            <!-- Start Widget -->
                <div class="row">
                    <form id="schedule_add">
                     <?php echo csrf_field(); ?>
                    <?php echo method_field("POST"); ?>
                        <div class="col-sm-8">
                            <div class="panel panel-border panel-info">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <a data-toggle="collapse" data-parent="#accordion-test" href="#collapseOne" class="collapsed">
                                           Schedule SMS Content
                                        </a>
                                    </h3>
                                </div>
                                    <div class="panel-body">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="app_id">APP Name</label><small class="req">*</small><br/>
                                                <select name="app_id" id="app_id" class="form-control selectpicker "  required data-container="body" data-live-search=true >
                                                    <option value="">--Select--</option>
                                                    <?php if(isset($app_name)): ?>
                                                        <?php $__currentLoopData = $app_name; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($value->id); ?>"><?php echo e($value->app_name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                </select>
                                                <?php $__errorArgs = ['app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <div id="content_body">
                                                <div class="content_body_sms" id="1">
                                                    <div class="form-group">
                                                        <label for="sms_body">SMS Body</label><small class="req">*</small><br/>
                                                        <textarea name="sms_body[]" maxlength="300" required class="form-control" placeholder="Type Your SMS" id="sms_body" cols="30" rows="5"></textarea>
                                                     <button class="btn btn-success m-l-10 m-t-5 plus_button" type="button"><i class="fa fa-plus"></i> </button><code id="remaining_1" class="pull-right">300 characters remaining</code>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-12">
                                            <div class="form-group pull-right m-t-22">
                                                <input type="submit" class=" btn btn-primary pull-right" value="Send SMS" name="submit" />
                                            </div>
                                        </div>
                                    </div> <!-- panel-body -->
                            </div> <!-- panel -->
                        </div> <!-- col -->
                        <?php echo Form::close(); ?>

                </div>
        </div> <!-- container -->
    </div>

<script src="<?php echo e(asset("admin")); ?>/vendors/notifications/notify.min.js"></script>
<script src="<?php echo e(asset("admin")); ?>/vendors/notifications/notify-metro.js"></script>
<script src="<?php echo e(asset("admin")); ?>/vendors/notifications/notifications.js"></script>
    <script >
        var x=0;
        var y=2;
        $(document).ready(function(){
            $('#content_body').on("keyup",'#sms_body',function(){
                var chars = this.value.length,
                    remaining = 300-chars;
                var id=$(this).closest(".content_body_sms").attr("id");
               $("#remaining_"+id).text(remaining + ' characters remaining');
            });

            $("#schedule_add").on("submit",function (e) {
                e.preventDefault();
                $.ajax({
                   data:$(this).serialize(),
                   url:"<?php echo e(route("user.schedule")); ?>",
                    type:"POST",
                    dataType:"json",
                    beforeSend:function(){
                       $("#overlay").fadeIn(300);　
                    },
                    success:function (data) {
                          $.Notification.autoHideNotify('success', 'top right',data.success);
                          $("#overlay").fadeOut(300);　
                          $("#schedule_add").trigger("reset");
                          $(".content_body_sms_2").remove();
                          $(".selectpicker").selectpicker("refresh");
                          y=2;
                          x=1;
                    },
                    error:function (e) {
                        $.Notification.autoHideNotify('error', 'top right',"Something Wrong");
                        $("#overlay").fadeOut(300);　
                    }

                });
            });
        });
    </script>

<script>
     $(document).ready(function(){
        var maxField = 10; //Input fields increment limitation
        var addButton = $('.plus_button'); //Add button selector
        var wrapper = $('#content_body'); //Input field wrapper

        //Once add button is clicked
        $('#content_body').on('click','.plus_button',function(){
            //Check maximum number of input fields
            if(x < maxField){
                x++; //Increment field counter
                $(wrapper).append(append_data(y++)); //Add field html
            }
        });
		function append_data(y)
		{
			var row="";
			row+='<div class="content_body_sms" id="'+y+'">';
			row+='<div class="content_body_sms_2"">';
			row+='<div class="col-sm-12">';
					row+='<div class="form-group">';
						row+='<label for="sms_body">SMS Body</label><small class="req">*</small><br/>';
						row+='<textarea name="sms_body[]" maxlength="300" required class="form-control" placeholder="Type Your SMS" id="sms_body" cols="30" rows="5"></textarea>';
						row+='<button class="btn btn-danger m-t-5 minus_button" type="button"><i class="fa fa-minus"></i> </button> <button class="btn btn-success m-l-10 m-t-5 plus_button" type="button"><i class="fa fa-plus"></i> </button><code id="remaining_'+y+'" class="pull-right">300 characters remaining</code>';
					row+='</div>';
				row+='</div>';
				row+='</div>';
				row+='</div>';
				return row;
		}
        //Once remove button is clicked
        $(wrapper).on('click', '.minus_button', function(e){
            e.preventDefault();
           // $("#content_body .content_body_sms:last-child").remove();
            $(this).closest('.content_body_sms').remove();
            x--; //Decrement field counter
        });
     });
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\shipan\htdocs\bdapps\resources\views/user/schedule/schedule.blade.php ENDPATH**/ ?>