<?php $__env->startSection('title_area'); ?>
Install App
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_section'); ?>
    <div class="content">
        <div class="container">
             <?php if(Session::has('message')): ?>
                <div class="alert alert-<?php echo e(Session::get("class")); ?>"><?php echo e(Session::get("message")); ?></div>
             <?php endif; ?>
            <!-- Start Widget -->
                <div class="row">
                    <?php if(isset($add)): ?>
                    <?php echo Form::open(['url' => 'user/install']); ?>

                    <?php echo method_field("POST"); ?>
                        <div class="col-sm-6">
                            <div class="panel-group panel-group-joined" id="accordion-test">
                                <div class="panel panel-border panel-info">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion-test" href="#collapseOne" class="collapsed">
                                                Install App
                                            </a>
                                        </h3>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse in">
                                        <div class="panel-body">
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="app_name">App Name</label><small class="req">*</small>
                                                    <input  name="app_name" type="text" class="form-control"  requiredid="app_name" placeholder="App Name">
                                                    <?php $__errorArgs = ['app_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="app_id">App ID</label><small class="req">*</small>
                                                    <input  name="app_id" type="text" class="form-control"  requiredid="app_id" placeholder="APP_XXXXXX">
                                                    <?php $__errorArgs = ['app_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="password">App Password</label><small class="req">*</small>
                                                    <input  name="password" type="text" class="form-control"  requiredid="password" placeholder="Password">
                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group">
                                                    <label for="sms_time">Sms Time</label><small class="req">*</small>
                                                    <div id="spinner4">
                                                        <div class="input-group">
                                                            <div class="spinner-buttons input-group-btn">
                                                                <button type="button" class="btn spinner-down btn-danger waves-effect waves-light">
                                                                    <i class="fa fa-minus"></i>
                                                                </button>
                                                            </div>
                                                            <input type="text" name="sms_time" class="spinner-input form-control" maxlength="2" readonly>
                                                            <div class="spinner-buttons input-group-btn">
                                                                 <button type="button" class="btn spinner-up btn-success waves-effect waves-light">
                                                                    <i class="fa fa-plus"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <?php $__errorArgs = ['sms_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="form-group m-t-22">
                                                    <select name="sms_time_format" id="sms_time_format" class="selectpicker form-control" data-container="body" >
                                                        <option value="0">AM</option>
                                                        <option value="1">PM</option>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-sm-12">
                                                <div class="form-group">
                                                    <label for="category_id">Category</label><small class="req">*</small>
                                                    <select name="category_id" id="category_id" class="selectpicker form-control" data-container="body" data-live-search=true>
                                                        <option value="">--Select--</option>
                                                        <?php if(isset($category)): ?>
                                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </select>
                                                    <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="invalid-feedback" role="alert">
                                                        <strong><?php echo e($message); ?></strong>
                                                    </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="col-sm-3">
                                                <div class="form-group pull-left m-t-22">
                                                    <input type="submit" class=" btn btn-primary pull-right" value="Install" name="submit" />
                                                </div>
                                            </div>
                                        </div> <!-- panel-body -->
                                    </div>
                                </div> <!-- panel -->
                            </div>
                        </div> <!-- col -->
                        <?php echo Form::close(); ?>

                    <?php endif; ?>
                </div>
        </div> <!-- container -->
    </div>
        <script type="text/javascript" src="<?php echo e(asset("admin")); ?>/vendors/spinner/spinner.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#spinner4').spinner({value:8, step: 1, min: 1, max: 12});
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\shipan\htdocs\bdapps\resources\views/user/installlapp/install.blade.php ENDPATH**/ ?>