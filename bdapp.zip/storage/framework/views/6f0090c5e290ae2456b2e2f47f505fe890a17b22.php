<?php $__env->startSection('title_area'); ?>
Instruction
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main_section'); ?>
    <div class="content">
        <div class="container">
            <!-- Start Widget -->
                <div class="row">
                    <div class="col-sm-8">
                            <div class="panel panel-border panel-info">
                                <div class="panel-heading">
                                    <h3 class="panel-title">
                                        <a data-toggle="collapse" data-parent="#accordion-test" href="#collapseOne" class="collapsed">
                                            Instruction
                                        </a>
                                    </h3>
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered">
                                            <tr>
                                                <td><strong>Allowed Host Address: </strong></td>
                                                <td><code id="host_address"><?php echo e($host_address); ?></code></td>
                                                <td><button onclick="copyText('<?php echo e($host_address); ?>')" class="btn btn-success">Copy Url</button></td>
                                            </tr>
                                            <tr>
                                                <td><strong>Message Receiving URL: </strong></td>
                                                <td><code id="sms_url"><?php echo e($sms_url); ?></code></td>
                                                <td><button  onclick="copyText('<?php echo e($sms_url); ?>')" class="btn btn-success">Copy Url</button></td>
                                            </tr>
                                            <tr>
                                                <td><strong>USSD Receiving URL: </strong></td>
                                                <td><code><?php echo e($ussd_url); ?></code></td>
                                                <td><button onclick="copyText('<?php echo e($ussd_url); ?>')" class="btn btn-success">Copy Url</button></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div> <!-- panel -->
                    </div> <!-- col -->
                </div>
        </div> <!-- container -->
    </div>
<script src="<?php echo e(asset("admin")); ?>/vendors/notifications/notify.min.js"></script>
<script src="<?php echo e(asset("admin")); ?>/vendors/notifications/notify-metro.js"></script>
<script src="<?php echo e(asset("admin")); ?>/vendors/notifications/notifications.js"></script>
    <script>
    function copyText(str) {
      const el = document.createElement('textarea');
      el.value = str;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      $.Notification.autoHideNotify('success', 'top right',"Copied");
      document.body.removeChild(el);
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\shipan\htdocs\bdapps\resources\views/user/instruction/instruction.blade.php ENDPATH**/ ?>