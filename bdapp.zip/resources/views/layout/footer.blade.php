<footer class="footer text-right">
        {{date("Y")}} © BDAPPS DAIRY.
    </footer>
